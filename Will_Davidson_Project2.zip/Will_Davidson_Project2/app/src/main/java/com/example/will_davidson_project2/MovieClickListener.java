package com.example.will_davidson_project2;

import android.view.View;

public interface MovieClickListener {

    public void onClick(View view, int position);
}
