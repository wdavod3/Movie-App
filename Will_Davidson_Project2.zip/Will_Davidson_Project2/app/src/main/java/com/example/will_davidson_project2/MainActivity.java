package com.example.will_davidson_project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    /*Declare items to hold the movie information*/
    ArrayList<String> movies;
    ArrayList<String> directors;
    ArrayList<Integer> poster;
    ArrayList<String> clip;
    ArrayList<String> movieInfo;
    ArrayList<String> dirInfo;
    RecyclerView movieView;
    RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView movieView = (RecyclerView) findViewById(R.id.recycler_view);

        /*Create the lists that have the information for the movies*/
        List<String> moviesN = Arrays.asList("Django\nUnchained", "Dope", "Enter\nThe Dragon", "Hero",
                "John Wick", "Scott Pilgrim\nvs. the world", "Sorry to\nBother You", "Superbad");

        List<String> directorsN = Arrays.asList("Quentin Tarantino", "Rick Famuyiwa", "Robert Clouse", "Zhang Yimou",
                "Chad Stahelski", "Edgar Wright", "Boots Riley", "Greg Mottola");

        List<String> clipsURL = Arrays.asList("https://www.youtube.com/watch?v=0fUCuvNlOCg", "https://m.youtube.com/watch?v=3ViVPRWRRmk",
                "https://www.youtube.com/watch?v=81jCPIag4KA", "https://m.youtube.com/watch?v=_USDk5jaGek",
                "https://m.youtube.com/watch?v=C0BMx-qxsP4", "https://m.youtube.com/watch?v=7wd5KEaOtm4",
                "https://www.youtube.com/watch?v=XthLQZWIshQ", "https://www.youtube.com/watch?v=4eaZ_48ZYog");

        List<String> movieURL = Arrays.asList("https://en.wikipedia.org/wiki/Django_Unchained", "https://en.wikipedia.org/wiki/Dope_(2015_film)",
                "https://en.wikipedia.org/wiki/Enter_the_Dragon", "https://en.wikipedia.org/wiki/Hero_(2002_film)",
                "https://en.wikipedia.org/wiki/John_Wick_(film)", "https://en.wikipedia.org/wiki/Scott_Pilgrim_vs._the_World",
                "https://en.wikipedia.org/wiki/Sorry_to_Bother_You", "https://en.wikipedia.org/wiki/Superbad");

        List<String> dirURL = Arrays.asList("https://en.wikipedia.org/wiki/Quentin_Tarantino", "https://en.wikipedia.org/wiki/Rick_Famuyiwa",
                "https://en.wikipedia.org/wiki/Robert_Clouse", "https://en.wikipedia.org/wiki/Zhang_Yimou",
                "https://en.wikipedia.org/wiki/Chad_Stahelski", "https://en.wikipedia.org/wiki/Edgar_Wright",
                "https://en.wikipedia.org/wiki/Boots_Riley", "https://en.wikipedia.org/wiki/Greg_Mottola");

        /*Save the information to the variables*/
        movies = new ArrayList<>();
        movies.addAll(moviesN);
        directors = new ArrayList<>();
        directors.addAll(directorsN);
        clip = new ArrayList<>();
        clip.addAll(clipsURL);
        movieInfo = new ArrayList<>();
        movieInfo.addAll(movieURL);
        dirInfo = new ArrayList<>();
        dirInfo.addAll(dirURL);
        /*Use for displaying the image for the movies*/
        poster = new ArrayList<>();
        poster.add(R.drawable.django);
        poster.add(R.drawable.dope);
        poster.add(R.drawable.enter);
        poster.add(R.drawable.hero);
        poster.add(R.drawable.john);
        poster.add(R.drawable.scott);
        poster.add(R.drawable.sorry);
        poster.add(R.drawable.superbad);

        /*Use for clicking on the movie items*/
        MovieClickListener listener = (view, position) -> {
            TextView movieName = (TextView)view.findViewById(R.id.movie_name);
        };

        /*Set up the adapter for the lists view*/
        MovieAdapter adapter = new MovieAdapter(movies, directors, poster, clip, movieInfo, dirInfo, listener, this);
        movieView.setHasFixedSize(true);
        movieView.setAdapter(adapter);
        layoutManager = new GridLayoutManager(this,2);
        movieView.setLayoutManager(layoutManager);

    }//end of onCreate

    /*Set up options menu*/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.movie_menu, menu);
        return true;
    }//end of onCreateOptionsMenu

    /*Use to choose between list view and grid view*/
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        RecyclerView movieView = (RecyclerView) findViewById(R.id.recycler_view);

        MovieClickListener listener = (view, position) -> {
            TextView movieName = (TextView)view.findViewById(R.id.movie_name);
        };

        MovieAdapter adapter = new MovieAdapter(movies, directors, poster, clip, movieInfo, dirInfo, listener, this);
        movieView.setAdapter(adapter);

        switch (item.getItemId()) {
            //list view was chose
            case R.id.list_view:
                layoutManager = new LinearLayoutManager(this);
                movieView.setLayoutManager(layoutManager);
                return true;
            //grid view was chose
            case R.id.grid_view:
                layoutManager = new GridLayoutManager(this,2);
                movieView.setLayoutManager(layoutManager);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }//end of switch case

    }//end of onOptionsItemSelected
}// end of MainActivity