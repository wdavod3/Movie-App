package com.example.will_davidson_project2;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.text.Layout;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolder> {

    /*Use to set upt each item in the lists*/
    private ArrayList<String> moviesAdap;
    private ArrayList<String> directorsAdap;
    private ArrayList<Integer> posterAdap;
    private ArrayList<String> clipAdap;
    private ArrayList<String> mInfo;
    private ArrayList<String> dInfo;
    private MovieClickListener MVlistener;
    private Context context;

    /*Bring information from MainActivity to the adapter*/
    public MovieAdapter(ArrayList<String> movieList, ArrayList<String> dirList, ArrayList<Integer> posterList, ArrayList<String> clipList,
                        ArrayList<String> mInfoList, ArrayList<String> dInfoList, MovieClickListener listener, Context context){
        moviesAdap = movieList;
        directorsAdap = dirList;
        posterAdap = posterList;
        clipAdap = clipList;
        mInfo = mInfoList;
        dInfo = dInfoList;
        this.MVlistener = listener;
        this.context = context;
    }//end of MovieAdapter()


    /*Use to set up the items in the list*/
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View listView = inflater.inflate(R.layout.movie_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listView, MVlistener);

        return viewHolder;
    }//end of ViewHolder

    /*Use to assign the names and image to each item in the list*/
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.movie.setText(moviesAdap.get(position));
        holder.director.setText(directorsAdap.get(position));
        holder.poster.setImageResource(posterAdap.get(position));
    }//end of onBindViewHolder

    /*Use to get the amount of items in the list*/
    @Override
    public int getItemCount() {
        return moviesAdap.size();
    }//end of getItemCount


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnCreateContextMenuListener{

        /*Declare the parts of the item used in the UI*/
        public TextView movie;
        public TextView director;
        public ImageView poster;
        private MovieClickListener listener;
        private View itemView;

        /*Use to set up the UI for each item*/
        public ViewHolder(@NonNull View itemView, MovieClickListener passedListener) {
            super(itemView);
            /*Set the names and image for the item*/
            movie = (TextView) itemView.findViewById(R.id.movie_name);
            director = (TextView) itemView.findViewById(R.id.director_name);
            poster = (ImageView) itemView.findViewById(R.id.imageView);
            this.itemView = itemView;

            /*Set up the long click for each item*/
            itemView.setOnCreateContextMenuListener(this);
            this.listener = passedListener;

            /*Set up the short click for each item*/
            itemView.setOnClickListener(this);
        }//end of ViewHolder


        /*Short click*/
        @Override
        public void onClick(View v) {
            listener.onClick(v, getAdapterPosition());
            /*Take user to video clip*/
            Intent video = new Intent(Intent.ACTION_VIEW, Uri.parse(clipAdap.get(getAdapterPosition())));
            context.startActivity(video);
        }//end of onClick

        /*Long click*/
        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            /*Set up the menu and the menu items*/
            MenuInflater inflater = new MenuInflater(v.getContext());
            inflater.inflate(R.menu.context_menu, menu );

            menu.getItem(0).setOnMenuItemClickListener(onMenuClip);
            menu.getItem(1).setOnMenuItemClickListener(onMenuMovie);
            menu.getItem(2).setOnMenuItemClickListener(onMenuDir);

        }//end of onCreateContextMenu

        /*Take user to movie clip*/
        private final MenuItem.OnMenuItemClickListener onMenuClip = new MenuItem.OnMenuItemClickListener(){
            @Override
            public boolean onMenuItemClick(MenuItem item){
                /*Movie clip*/
                Intent video = new Intent(Intent.ACTION_VIEW, Uri.parse(clipAdap.get(getAdapterPosition())));
                context.startActivity(video);
                return true;
            }//end of onMenuItemClick
        };//end of onMenuClip

        /*Take user to movie info site*/
        private final MenuItem.OnMenuItemClickListener onMenuMovie = new MenuItem.OnMenuItemClickListener(){
            @Override
            public boolean onMenuItemClick(MenuItem item){
                /*Movie info*/
                Intent video = new Intent(Intent.ACTION_VIEW, Uri.parse(mInfo.get(getAdapterPosition())));
                context.startActivity(video);
                return true;
            }//end of onMenuItemClick
        };//end of onMenuMovie

        /*Take user to director info site*/
        private final MenuItem.OnMenuItemClickListener onMenuDir = new MenuItem.OnMenuItemClickListener(){
            @Override
            public boolean onMenuItemClick(MenuItem item){
                /*Director info*/
                Intent video = new Intent(Intent.ACTION_VIEW, Uri.parse(dInfo.get(getAdapterPosition())));
                context.startActivity(video);
                return true;
            }//end of onMenuItemClick
        };//end of onMenuDir

    }//end of ViewHolder
}//end of MovieAdapter
